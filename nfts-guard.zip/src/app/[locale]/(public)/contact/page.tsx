"use client";

import React from "react";
import ContactSection from "@/components/contact/ContactSection";

const page: React.FC = () => {
  return (
    <>
      <ContactSection />
    </>
  );
};

export default page;
