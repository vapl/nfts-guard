"use client";

import FAQSection from "@/components/FaqSection";
import React from "react";

const page: React.FC = () => {
  return <FAQSection />;
};

export default page;
