export const locales = ["en", "es"];
export const defaultLocale = "en";
