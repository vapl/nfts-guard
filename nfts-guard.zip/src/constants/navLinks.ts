export const getNavLinks = () => [
  { name: "Home", href: "/" },
  { name: "Scanner (beta)", href: "scanner" },
  // { name: "About", href: "#about" },
  // { name: "Prices", href: "#prices" },
  // { name: "Marketplaces", href: "#marketplaces" },
  { name: "FAQ", href: "/faq" },
  // { name: "Blog", href: "#blog" },
  { name: "Get in touch", href: "/contact" },
];
