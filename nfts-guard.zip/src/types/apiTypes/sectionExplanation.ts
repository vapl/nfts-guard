export type SectionMetric = {
  label: string;
  value: string | number;
};
