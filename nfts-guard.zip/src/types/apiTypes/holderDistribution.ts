export interface HolderDistribution {
  "1": number;
  "2-5": number;
  "6-10": number;
  "11+": number;
}
